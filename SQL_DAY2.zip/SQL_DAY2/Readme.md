# 📊 SQL Day 2 – Intermediate Progress (SQLBolt Lessons 11–18)

## ✅ Coverage Summary
On Day 2, I went beyond the SQL basics and worked through **intermediate concepts** up to **Lesson 18 on SQLBolt**.  
This set of lessons focused on **refining queries, filtering, and handling tables** in more depth.

---

## 🔑 Topics Learned

### 1. Filtering & Pattern Matching
- `WHERE` with conditions (`=`, `<`, `>`, `!=`, `BETWEEN`)
- Pattern matching with `LIKE`
  - `%` → matches any sequence  
  - `_` → matches a single character
- Filtering with `IN` for multiple values
- Using `NULL` and `IS NULL`

### 2. Sorting & Limiting
- Ordering results with `ORDER BY`
- Sorting in ascending (`ASC`) or descending (`DESC`)
- Restricting rows with `LIMIT`

### 3. Aggregate Functions
- Counting rows → `COUNT(*)`
- Summation & averages → `SUM()`, `AVG()`
- Min/max values → `MIN()`, `MAX()`

### 4. Grouping Data
- Grouping rows by column(s) → `GROUP BY`
- Filtering groups → `HAVING` vs `WHERE`
  - `WHERE` filters rows **before aggregation**
  - `HAVING` filters groups **after aggregation**

### 5. Table Operations
- Adding new data → `INSERT INTO ... VALUES(...)`
- Updating existing records → `UPDATE ... SET ... WHERE`
- Removing records → `DELETE FROM ... WHERE`
- Modifying schema → `ALTER TABLE`
  - Add / remove / rename columns
- Dropping a table completely → `DROP TABLE`

---

## 📌 Key Insights
- `WHERE` vs `HAVING` is crucial: row-level vs group-level filtering.  
- Pattern matching with `LIKE` is useful for text queries.  
- Always pair `UPDATE` and `DELETE` with **strong conditions** to avoid accidental full-table modifications.  

---

## 🚀 Next Steps
- Move into **JOINs** (inner, left, right, full) for multi-table queries.  
- Start practicing **real-world datasets** (e.g., employees, sales, orders).  
- Build mini-projects:  
  - Analytics queries on sample data  
  - CRUD operations with a small schema  

---
👨‍💻 *Day 2 complete. Intermediate SQL foundations are set. Next: mastering joins!*
