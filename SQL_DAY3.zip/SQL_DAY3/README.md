# Advanced SQL Concepts 🚀

This repository documents my learnings on **Advanced SQL** as part of my #100DaysOfCloudData journey.  
While basic SQL covers CRUD operations and filtering, advanced SQL gives the real power to solve complex data problems at scale.  

---

## 🔑 Topics Covered

### 1. Window Functions
These let you perform calculations across rows without collapsing them. Useful for ranking, running totals, and moving averages.  

```sql
SELECT customer_id, amount,
       RANK() OVER (PARTITION BY region ORDER BY amount DESC) AS rank_in_region
FROM sales;

2. Common Table Expressions (CTEs)

CTEs make queries cleaner by breaking them into smaller steps.

WITH regional_sales AS (
    SELECT region, SUM(amount) AS total
    FROM sales
    GROUP BY region
)
SELECT region, total
FROM regional_sales
WHERE total > 100000;

3. Subqueries

Subqueries help filter or compare data using another query inside.

SELECT name, salary
FROM employees
WHERE salary > (SELECT AVG(salary) FROM employees);

4. Joins Beyond Basics

Beyond INNER and LEFT joins, you can use FULL OUTER or CROSS joins to combine datasets.

SELECT a.id, a.name, b.order_id
FROM customers a
FULL OUTER JOIN orders b ON a.id = b.customer_id;

5. Set Operations

Use UNION, INTERSECT, and EXCEPT to merge or compare result sets.

SELECT user_id FROM web_users
INTERSECT
SELECT user_id FROM mobile_users;
