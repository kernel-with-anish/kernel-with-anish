# SQL Day 1 – Basics & Functions

## 📌 What I Learned
- Introduction to SQL and its role in databases  
- Basic SQL syntax: `SELECT`, `FROM`, `WHERE`, `ORDER BY`, `LIMIT`  
- Filtering data with conditions: `=`, `>`, `<`, `AND`, `OR`, `NOT`  
- Aggregate functions: `COUNT()`, `SUM()`, `AVG()`, `MIN()`, `MAX()`  
- Grouping and summarizing with `GROUP BY`  
- Simple string and date functions: `LENGTH()`, `UPPER()`, `LOWER()`, `NOW()`  

---

## 📝 Practice Queries
```sql
-- Select all rows from a table
SELECT * FROM employees;

-- Find employees in a specific department
SELECT name, salary FROM employees WHERE department = 'Sales';

-- Count number of orders
SELECT COUNT(*) FROM orders;

-- Find average salary in each department
SELECT department, AVG(salary) 
FROM employees 
GROUP BY department;

-- Get current date
SELECT NOW();
